﻿// See https://aka.ms/new-console-template for more information



using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Merhaba, Dünya!");  // Ekrana "Merhaba, Dünya!" yazdırma
    }
}


